// App.js

import React from "react";
import "./App.css";
import ProjectsAdminPage from "./Components/admin/ProjectsAdminPage";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./Components/home/HomePage";
import AboutMe from "./Components/home/AboutMe";
import Contact from "./Components/home/Contact";
import Login from "./Components/home/Login";
import Navbar from "./Components/Navbar";
import ProjectPage from "./Components/Projectpage";
import ProjectsPage from "./Components/ProjectsPage";

function App() {
    return (
        <Router>
            <Navbar />
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/payload" element={<ProjectsPage />} />
                <Route path="/payload/admin" element={<ProjectsAdminPage />} />

                {/* Tidak perlu import Admin di sini */}
                {/* <Route path="/payload/admin" element={<Admin />} /> */}
                {/* Tambahkan rute untuk halaman projek di sini */}
                <Route path="/payload/project/:id" element={<ProjectPage />} />
                <Route path="/about" element={<AboutMe />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/home" element={<HomePage />} />
            </Routes>
        </Router>
    );
}

export default App;
