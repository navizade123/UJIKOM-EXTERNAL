import React, { useState } from "react";
import ProjectCard from "./ProjectCard";
import ProjectForm from "./ProjectForm";

const ProjectList = ({ projects, onSave, setProjects }) => {
  const [projectBeingEdited, setProjectBeingEdited] = useState({});
  const [input, setInput] = useState("")

  const handleEdit = (project) => {
    setProjectBeingEdited(project);
  };

  const cancelEditing = () => {
    setProjectBeingEdited({});
  };
  return (
    <>
      <input type="text" onChange={(e) => setInput(e.target.value)} />
    <div className="row">
      {projects?.filter((i) => i.name.toLowerCase().indexOf(input) > -1)
      .map((project) => (
        <div key={project.id} className="cols-row">
          {project === projectBeingEdited ? (
            <ProjectForm
              onSave={onSave}
              onCancel={cancelEditing}
              project={project}
              />
              ) : (
                <ProjectCard project={project} onEdit={handleEdit} setProjects={setProjects} projects={projects} />
                )}
        </div>
      ))}
    </div>
      </>
  );
};

export default ProjectList;
