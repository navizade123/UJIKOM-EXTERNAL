import React from "react";
import { projectAPI } from "./ProjectAPI";
import { NavLink } from "react-router-dom";

const FormatDescription = (description) => {
  if (description && description.length > 50) {
    return description.substring(0, 50) + "...";
  }
  return description;
};

const ProjectCard = (props) => {
  const { project, onEdit, setProjects, projects } = props;

  const handleEditClick = (projectBeingEdited) => {
    onEdit(projectBeingEdited);
  };

  const handleDeleteClick = (projectBeingDeleted) => {
    setProjects(projects.filter((project) => project.id !== projectBeingDeleted.id));
    // projectAPI.delete(projectBeingDeleted.id);
  };

  const username = localStorage.getItem("username")

  return (
    <div className="card">
      <img src={project.img_link} alt={project.name} />
      <section className="section dark">
        <h5 className="strong">
          <strong>{project.name}</strong>
        </h5>
        <NavLink to={"/project/" + project.id}>
        <p>{FormatDescription(project.description)}</p>
        </NavLink>
        <p>Price: {`${project.currency}${project.price.toLocaleString()}`}</p>
        {username == "admin" && 
        <>
        <button className="bordered" onClick={() => handleEditClick(project)}>
          <span className="icon-edit"></span>
          Edit
        </button>
        <button className="bordered" onClick={() => handleDeleteClick(project)}>
          <span className="icon-alert"></span>
          Delete
        </button>
        </>
        }
      </section>
    </div>
  );
};

export default ProjectCard;
