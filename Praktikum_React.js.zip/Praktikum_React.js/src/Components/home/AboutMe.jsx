    // Components/AboutMe.js
import React from 'react';
import "./AboutMe.css";

const AboutMe = () => {
  return (
    <div>
      <h1 className='text2'>About</h1>
      <p>
      "Raih kenyamanan dan keindahan dalam rumah Anda dengan alat furniture inovatif kami! Merancang dan menyusun perabotan rumah tangga dapat menjadi pengalaman yang menyenangkan atau bahkan menantang, tetapi dengan alat furniture kami, semua itu menjadi lebih mudah dan efisien.

Alat furniture kami dirancang dengan cermat untuk memastikan bahwa setiap langkah perakitan dan penataan furniture berjalan lancar. Anda tidak perlu lagi khawatir tentang mengejar baut yang hilang atau kebingungan mengenai urutan langkah-langkah. Dengan panduan yang jelas dan user interface yang intuitif, alat kami memastikan bahwa setiap pengguna, baik yang berpengalaman maupun pemula, dapat dengan mudah mengatasi tugas-tugas rumit..
      </p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus magni nulla aut, nisi laborum autem error saepe corrupti. Error itaque veniam maxime eum blanditiis, fugit ad neque eaque ea dolore.
      </p>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo temporibus iure nesciunt officia itaque aspernatur. Amet impedit, repudiandae quod harum provident eum, dicta quos repellat voluptas dolorum recusandae laboriosam nihil.
      </p>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim deleniti veniam error iusto quas eaque maxime commodi ea voluptatibus sed eos necessitatibus delectus perspiciatis aut dignissimos, fugit expedita maiores similique.
      </p>
    </div>
  );
};

export default AboutMe;
