import React from "react";
import "./homepage.css";
import "./footer.css"

const HomePage = () => {
  return (
    <div>
      <div className="image-container">
        <img src="5.jpg" className="gambar" alt="A descriptive text" />
        
      </div>
      <div className="footer">
        <div className="contact">
          <h4>Contact Us</h4>
          <p>Phone: 0627069701</p>
        </div>
        <div className="Alamat">    
        <h2>Alamat</h2>
          <p>Address: Jl. Pedurenan Masjid III, Jakarta City, Jakarta 1294</p>
        </div>
        <div className="social-media">
          <h4>Follow Us</h4>
          <a
            href="https://www.instagram.com/Furniture/"
            target="_blank"
            rel="noopener noreferrer"
          >
            Instagram 
          </a>
        </div>
      </div>
      </div>
  );
};

export default HomePage;