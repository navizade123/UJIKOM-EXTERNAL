import React from 'react'
import { Link } from 'react-router-dom'
import Project from './ProjectsPage'


const ProjectDetail = ({ project, onCancel }) => {
    console.log(project);
    return (
        <div className='row'>
        </div>
    )
}

export default ProjectDetail``