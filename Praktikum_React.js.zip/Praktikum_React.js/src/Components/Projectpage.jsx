import React, {useEffect, useState} from "react";
import { projectAPI } from "./ProjectAPI";
import { Link, useParams } from "react-router-dom";


const ProjectPage = (props) => {
    const [loading, setLoading] = useState(false)
    const [project, setProject] = useState(null)
    const [error, setError] = useState(null)
    const params = useParams();
    const id = params.id

    
    useEffect(()=>{
        setLoading(true)
        projectAPI.find(id).then(data =>{
            setProject(data);
            setLoading(false);
        }).catch(e =>{
            setError(e);            
            setLoading(false);
        });
    }, [id]);
    return(
        <div>
            {loading &&(
                <div className="center-page">
                    <span className="spinner primary"></span>
                    </div>
            )}

            {error &&(
                <div className="row">
                    <div className="card large error">
                        <section>
                            <p>
                                <span className="icon-alert inverse"></span>
                                {error}
                            </p>
                        </section>
                    </div>
                </div>
            )}
            {/* {project && <ProjectDetail project={project}/>} */}
            <div className='row'>
                {project && 
            <div className="col-sm-6">
            {console.log("test")}
            <div className="card large">
            <img src={project.img_link} alt={project.name} className='rounded' />
            <section className="section dark">
            <h3 className="strong">
            <strong>{project.name}</strong>
            </h3>
            <p>{project.description}</p>
            <p>Price : {`${project.currency}${project.price.toLocaleString()}`}</p>
            <Link to = "http://localhost:3000/payload" type="button" className="btn">Back</Link>
            </section>
            </div>
        </div> 
    }
        </div>
        </div>
    )
}

export default ProjectPage;