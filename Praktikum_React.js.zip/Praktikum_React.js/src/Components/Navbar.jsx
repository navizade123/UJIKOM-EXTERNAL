import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import "../App.css";

const Navbar = () => {
  const location = useLocation();

  // Define the pages where you want to hide the navbar
  const hideNavbarOnPages = ["/", "/payload/admin"];

  // Check if the current route is one of the pages where you want to hide the navbar
  const shouldHideNavbar = hideNavbarOnPages.includes(location.pathname);

  // Render the navbar only if it's not one of the specified pages
  return (
    !shouldHideNavbar && (
      <header className="navbars">
        <NavLink to="/home" className="button rounded">
          <span className="icon-home"></span>
          Home
        </NavLink>

        <NavLink to="/payload" className="button rounded">
          Store
        </NavLink>

        <NavLink to="/about" className="button rounded">
          About
        </NavLink>

        <NavLink to="/contact" className="button rounded">
          Comment
        </NavLink>
      </header>
    )
  );
};

export default Navbar;
