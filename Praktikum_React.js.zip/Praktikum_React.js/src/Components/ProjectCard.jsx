import React from "react";
import { projectAPI } from "./ProjectAPI";
import { NavLink } from "react-router-dom";

const FormatDescription = (description) => {
  if (description && description.length > 50) {
    return description.substring(0, 50) + "...";
  }
  return description;
};

const ProjectCard = (props) => {
  const { project, setProjects, projects } = props;

  const username = localStorage.getItem("username")

  return (
    <div className="card">
      <img src={project.img_link} alt={project.name} />
      <section className="section dark">
        <NavLink to={"/project/" + project.id}>
        <h5 className="strong">
          <strong>{project.name}</strong>
        </h5>
        </NavLink>
        <p>{FormatDescription(project.description)}</p>
        <p>Price: {`${project.currency}${project.price.toLocaleString()}`}</p>

        {username == "user" || username == "admin" ?
        <button className="bordered">
          <span className="icon-edit"></span>
          Buy
        </button> :
        <></>
        }
      </section>
    </div>
  );
};

export default ProjectCard;
